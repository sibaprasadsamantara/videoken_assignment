class Renamecolumntypeentries < ActiveRecord::Migration[5.0]
  def change
  	rename_column :entries, :type, :entry_type
  end
end
