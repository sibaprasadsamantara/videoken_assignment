Rails.application.routes.draw do
  
  get '/tags/:entity_type/:entity_id', to: 'entries#get_entries'
  get '/stats', to: 'entries#collect_stats'
  get '/stats/:entity_type/:entity_id', to: 'entries#get_stats' 

end


