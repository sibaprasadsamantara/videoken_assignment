module Api::EntriesHelper
end
