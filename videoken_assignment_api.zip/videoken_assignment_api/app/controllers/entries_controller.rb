class EntriesController < ApplicationController

	respond_to :json

	def get_entries
	  respond_with(get_entry(entity_id: params[:entity_id]))
	end

	def collect_stats
	  entries = get_all_entries.group_by(&:tags)
	  result = nil
	  entries.each do |key, value|
	  	(result ||= []).push({"#{key}": value.count})
	  end
	  respond_with(result)
	end

	def get_stats	
	end

    private

      def get_entry(entity_id:)
      	Entry.find_by id: entity_id || "Not Found"
      end

      def get_all_entries
      	Entry.all
      end
end
