class Api::EntriesController < ApplicationController
end
